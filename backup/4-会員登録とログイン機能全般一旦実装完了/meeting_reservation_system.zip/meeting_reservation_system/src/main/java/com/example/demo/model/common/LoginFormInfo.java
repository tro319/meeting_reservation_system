package com.example.demo.model.common;

import lombok.Data;

@Data
public class LoginFormInfo {
	
	private String email;
	
	private String pass;

}
