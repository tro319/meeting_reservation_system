package com.example.demo.kyoutu;

public class ErrMessageConst {
	
	public static final String LOGIN_ERR_INPUT = "login.errInput";

}
